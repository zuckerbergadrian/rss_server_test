from django.apps import AppConfig


class RssModelConfig(AppConfig):
    name = 'rss_model'
